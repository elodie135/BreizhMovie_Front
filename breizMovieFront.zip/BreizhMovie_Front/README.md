# BreizhMovie_Front
Pour le front j'ai crée un visuel sur photoshop pour me donnée une idée de l'axe que j'allais prendre, ensuite j'ai crée pour chaques pages un fichier html, un css et un js. J'ai utilisée bootstrap pour un rendu plus rapide. 
j'avoue c'est pas pas du tout organisé, lorsque je crée un dossier avec toutes mes photos je perd beaucoup de temps a réussir à les récuperées doncj'ai préféré privilegié le resultat à l'organisation vu que les fichiers photo et les pages n'était pas si nombreux.
